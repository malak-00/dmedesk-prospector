# Notice

Impeccable
Copyright 2025 Paul Bakaus

## Anthropic frontend-design Skill

The `frontend-design` skill in this project builds on Anthropic's original frontend-design skill.

**Original work:** https://github.com/anthropics/skills/tree/main/skills/frontend-design
**Original license:** Apache License 2.0
**Copyright:** 2025 Anthropic, PBC

This project extends the original with:
- 7 domain-specific reference files (typography, color-and-contrast, spatial-design, motion-design, interaction-design, responsive-design, ux-writing)
- 20 steering commands
- Expanded patterns and anti-patterns
